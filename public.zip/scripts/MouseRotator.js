import * as THREE from 'three';
class MouseRotator {
    constructor(renderer, model, options) {
        this.model = model;
        const baseX = options.minXSpeed === undefined ? 0 : options.minXSpeed;
        const baseY = options.minYSpeed === undefined ? 0 : options.minYSpeed;
        const move = { x: baseX, y: baseY }
        const prev = { x: 0, y: 0 };
        let isDragging = false;
        let selected = false;
        renderer.listenOnCanvas("mouseup", function() {
            isDragging = false;
        });
        renderer.onClickEvent((object) => {
            if (object == this.model) selected = true;
            else selected = false;
        });
        renderer.listenOnCanvas('mousedown', function(event) {
            isDragging = true;
            prev.x = event.clientX;
            prev.y = event.clientY;
        });
        renderer.listenOnCanvas('mousemove', function(event) {
            if (isDragging && selected) {
                move.x = event.clientX - prev.x;
                move.y = event.clientY - prev.y;
                prev.x = event.clientX;
                prev.y = event.clientY;
            }
        });
        const speed = options.rotateSpeed;
        renderer.onFrameUpdate((scene, delta) => {
            move.x = move.x > baseX ? Math.max(baseX, move.x-options.haltSpeed) : Math.min(baseX, move.x+options.haltSpeed);
            move.y = move.y > baseY ? Math.max(baseY, move.y-options.haltSpeed) : Math.min(baseY, move.y+options.haltSpeed);
            this.model.quaternion.multiplyQuaternions(new THREE.Quaternion()
                    .setFromEuler(new THREE.Euler(
                        (move.y * speed) * (Math.PI / 180) * delta,
                        (move.x * speed) * (Math.PI / 180) * delta,
                        0,
                        'XYZ'
            )), this.model.quaternion);
        });
    }
}
class MouseRotatorOptions {
    constructor(rotateSpeed, haltSpeed, minXSpeed, minYSpeed) {
        this.rotateSpeed = rotateSpeed;
        this.haltSpeed = haltSpeed;
        this.minXSpeed = minXSpeed;
        this.minYSpeed = minYSpeed;
    }
}

export { MouseRotator, MouseRotatorOptions }