class Orbitor {
    constructor(renderer, center, object, distance, speed) {
        this.renderer = renderer;
        this.center = center;
        this.object = object;
        this.a = 0;
        this.distance = distance;
        this.speed = speed;
    }

    init() {
        this.renderer.onFrameUpdate((scene, delta) => {
            this.a += this.speed*(delta);
            let a = this.a;
            let x = 0;
            let z = 0;
            if (a > 360) a = 0;
            if (a > 270) {
                a -= 180;
                x = -Math.sin(a);
                z = Math.cos(a);
            } else if (a > 180) {
                a -= 180;
                x = -Math.sin(a);
                z = -Math.cos(a);
            } else if (a > 90) {
                a -=90;
                x = Math.sin(a);
                z = -Math.cos(a);
            } else {
                x = Math.sin(a);
                z = Math.cos(a);
            }
            this.object.position.x = ((x*this.distance) + this.center.position.x);
            //this.object.position.x = x + this.center.position.y;
            this.object.position.z = ((z*this.distance) + this.center.position.z);
        });
    }
}

export { Orbitor }