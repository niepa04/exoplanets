import * as THREE from 'three';

class PerspectiveCamera extends THREE.PerspectiveCamera {
    localPosition = { x:0, y:0, z:0 }
    orbitRotation = { h:0, v:0 }
    #pointOfInterest = undefined;
    lookAtPointOfInterest = false;
    followPointOfInterest = false;
    constructor(r, pov, thin2, b, c) {
        super(pov, thin2, b, c);
        let isDragging = false;
        r.listenOnCanvas("mouseup", function() {
            isDragging = false;
        });
        const prev = { x:0, y:0 };
        r.listenOnCanvas('mousedown', function(event) {
            isDragging = true;
            prev.x = event.clientX;
            prev.y = event.clientY;
        });
        const pc = this;
        r.listenOnCanvas('mousemove', function(event) {
            if (isDragging && pc.getPOI() != undefined) {
                pc.orbitRotation.h += (event.clientX - prev.x)/100;
                pc.orbitRotation.v += (event.clientY - prev.y)/25;
                let h = pc.orbitRotation.h%360;
                let v = pc.orbitRotation.v%360;
                prev.x = event.clientX;
                prev.y = event.clientY;
                let x = 0;
                let z = 0;
                if (h > 270) {
                    h -= 270;
                    x = -Math.sin(h);
                    z = Math.cos(h);
                } else if (h > 180) {
                    h -= 180;
                    x = -Math.sin(h);
                    z = -Math.cos(h);
                } else if (h > 90) {
                    h -=90;
                    x = Math.sin(h);
                    z = -Math.cos(h);
                } else {
                    x = Math.sin(h);
                    z = Math.cos(h);
                }
                pc.mouseRotate(x*5, 0, z*5);
                pc.lookAtPOI();
            }
        });
    }

    mouseRotate(x, y, z) {
        this.localPosition.x = (x + this.#pointOfInterest.position.x);
        this.localPosition.y = (y + this.#pointOfInterest.position.y);
        this.localPosition.z = (z + this.#pointOfInterest.position.z);
    }
    keepLookingAtPOI(object) {
        this.#pointOfInterest = object;
        this.lookAtPointOfInterest = true;
        this.lookAtPOI();
    }

    getPOI() {
        return this.#pointOfInterest;
    }

    lookAtPOI() {
        if (this.#pointOfInterest instanceof THREE.Object3D) {
            const ld = new THREE.Vector3();
        }
    }

    followPOI() {
        const p = this.#pointOfInterest.position;
        this.position.x = p.x + this.localPosition.x;
        this.position.y = p.y + this.localPosition.y;
        this.position.z = p.z + this.localPosition.z;
    }
    
    setPOI(object) {
        this.#pointOfInterest = object;
    }
    #mouseOrbitAroundObject = false;
    mouseOrbitAroundObject(value) {
        this.#mouseOrbitAroundObject = true == value;
        this.lookAtPointOfInterest = true == value;
    }

    followObject(object) {
        if (object instanceof THREE.Object3D) {
            this.#pointOfInterest = object;
            this.followPointOfInterest = true;
            // this.lookAtPointOfInterest = true;
            // this.localPosition.x = this.position.x;
            // this.localPosition.y = this.position.y;
            // this.localPosition.z = this.position.z;
            // console.log("folowin");
        }
    }

    setPos(pos) {
        this.position.x = pos[0];
        this.position.y = pos[1];
        this.position.z = pos[2];
    }
}

export { PerspectiveCamera }