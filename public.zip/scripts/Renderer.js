import * as THREE from 'three';
import { GLTFLoader } from '../three/examples/jsm/loaders/GLTFLoader.js';
import { Rotator } from './Rotator.js';
import { TextureSwapper } from './TextureSwapper.js'
import { Orbitor } from './Orbitor.js';
import { PerspectiveCamera } from './PerspectiveCamera.js';
import { MouseRotator } from "./MouseRotator.js"
import { MouseRotatorOptions } from './MouseRotator.js';

const mvr = document.getElementById("mover");
new THREE.Object3D();
class Renderer {
    delta = 0;
    #canvas;
    #renderer;
    #camera;
    #paused = false;
    #running = false;
    #endRun = false;
    #mouse = new THREE.Vector2();
    #raycaster = new THREE.Raycaster();
    #updates = [];
    #onClickEvents = [];
    #scenes = [];
    #currentScene = 0;
    simulationSpeed = 1;
    #previousTime;
    #runInBackground = true;
    constructor(canvas) {
        this.#canvas = canvas;
        const c = this.#canvas;
        this.#renderer = new THREE.WebGLRenderer({ canvas: c });
        this.#renderer.setSize(window.innerWidth, window.innerHeight);
        this.#camera = new PerspectiveCamera(this, 60, window.innerWidth / window.innerHeight, 0.1, 1000);
        window.addEventListener('mousemove', (event) => {
            this.#mouse.x = (event.clientX / this.getClientWidth()) * 2 - 1;
            this.#mouse.y = -(event.clientY / this.getClientHeight()) * 2 + 1;
        });
        window.addEventListener('mousedown', () => {
            this.#raycaster.setFromCamera(this.#mouse, this.#camera);
            const intersects = this.#raycaster.intersectObjects(this.#scenes[this.#currentScene].children, true);
            let object = undefined;
            if (intersects.length > 0)
                object = intersects[0];
            if (this.#onClickEvents[this.#currentScene] != undefined) for (let func of this.#onClickEvents[this.#currentScene])
                func(object);
        });
        window.addEventListener('blur', () => { if (!this.#runInBackground && !this.#paused) this.pause(); })
        window.addEventListener('focus', () => { if (!this.#runInBackground && this.#paused) this.unpause(); })
        window.addEventListener('resize', () => {
            this.#renderer.setSize(window.innerWidth, window.innerHeight);
            this.#camera.aspect = window.innerWidth / window.innerHeight;
            this.#camera.updateProjectionMatrix();
        });
    }

    getMouse() {
        return this.#mouse;
    }

    runInBKG(value) {
        this.#runInBackground = true == value;
        if (!document.hasFocus() && !this.#runInBackground && !this.#paused) this.pause();
    }

    #run() {
        try {
            if (this.#endRun) {
                this.#endRun = false;
                return;
            }
            requestAnimationFrame(this.#run.bind(this));
            const currentTime = performance.now();
            const delta = (currentTime - this.#previousTime) / 1000;
            this.#previousTime = currentTime;
            if (this.#updates[this.#currentScene] !== undefined) for (let func of this.#updates[this.#currentScene])
                func(this.#scenes[this.#currentScene], delta*this.simulationSpeed);
            if (this.#camera.getPOI() !== undefined) {
                if (this.#camera.followPointOfInterest) this.#camera.followPOI();
                else if (this.#camera.lookAtPointOfInterest) this.#camera.lookAtPOI();
            }
            this.delta = delta;
            this.#renderer.render(this.#scenes[this.#currentScene], this.#camera);
        } catch (error) {
            this.pause();
            console.error(error);
        }
    }

    start() {
        if (this.#currentScene >= this.#scenes.length || this.#scenes.length == 0 || this.#scenes[this.#currentScene] == undefined) {
            for (let i = 0; i < this.#scenes.length; i++) {
                if (this.#scenes[i] != undefined) {
                    this.#scenes.push(new THREE.Scene());
                    this.loadScene(i);
                }
            }
            if (this.#scenes[0] == undefined) {
                this.#scenes.push(new THREE.Scene());
                this.#currentScene = 0;
            }
        }
        if (!document.hasFocus() && !this.#runInBackground && !this.#paused) this.pause();
        this.#renderer.render(this.#scenes[this.#currentScene], this.#camera);
        this.#run();
        this.#running = true;
    }

    isRunnung() {
        return this.#running;
    }

    scale(object, size) {
        object.scale.x = size;
        object.scale.y = size;
        object.scale.z = size;
    }

    getCanvas() {
        return this.#canvas;
    }

    listenOnCanvas(eventType, onEvent) {
        this.#canvas.addEventListener(eventType, onEvent);
    }

    onFrameUpdate(func, scene) {
        const s = isNumber(scene) ? scene : this.#currentScene;
        if (this.#updates[s] == undefined)
            this.#updates[s] = [];
        this.#updates[s].push(func);
    }
    onClickEvent(func, scene) {
        const s = isNumber(scene) ? scene : this.#currentScene;
        if (this.#onClickEvents[s] == undefined)
            this.#onClickEvents[s] = [];
        this.#onClickEvents[s].push(func);
    }

    getCurrentScene() {
        return this.#scenes[this.#currentScene];
    }

    getScene(scene_id) {
        return this.#scenes[scene_id];
    }

    addScene(scene) {
        if (scene == undefined) {
            console.log("Scene is undefined.");
            return;
        } else if (!(scene instanceof THREE.Scene))
            throw new Error("Passing '" + scene.type + "' as THREE.Scene");
        this.#scenes.push(scene);
        return this.#scenes.length-1;
    }

    loadScene(scene) {
        if (scene instanceof THREE.Scene) {
            this.addScene(scene);
            this.#currentScene = this.#scenes.length-1;
        } else this.#currentScene = scene;
    }

    #prevSpeed = 1;
    pause() {
        this.#prevSpeed = this.simulationSpeed;
        this.simulationSpeed = 0;
        this.#paused = true;
        this.#endRun = true;
    }

    unpause() {
        this.simulationSpeed = this.#prevSpeed;
        this.#previousTime = performance.now();
        this.#run();
        this.#paused = false;
    }

    stop() {
        this.#endRun = true;
        this.#running = false;
    }

    isRunning() {
        return this.#running;
    }

    getCamera() {
        return this.#camera;
    }

    planetCloseupScene(model, planetName) {
        const scene = new THREE.Scene();
        if (model instanceof THREE.Object3D) scene.add(model);
        else {
            const r = this;
            let camera = this.#camera;
            camera.position.set(0, 0, 10);
            this.loadModel(model, [0, 0, 0], planetName, scene, (object) => {
                camera.lookAt(object.position);
                new MouseRotator(r, camera, new MouseRotatorOptions(10, 5, 2, -0.5));
                new Rotator(r, object.children[0], 0, .5, 0);
                this.#camera.setPos([0, 5, 20]);
                r.getCamera().keepLookingAtPOI(object);
                r.getCamera().lookAtPointOfInterest = true;
                object.rotation.z = .3;
            });
            // this.onClickEvent((object) => {
            //     if (object != undefined && object.object.parent != undefined) {
            //         this.#camera.followObject(object.object.parent);
            //     }
            // }, 1);
        }
        scene.background = new THREE.Color(0x070707);   
        this.createLight("SPOTLIGHT", 0x909090, 10, [2, 0, 0], scene);
        this.createLight("SPOTLIGHT", 0x909090, 10, [-2, 0, 0], scene);
        this.createLight("AMBIENTLIGHT", 0xffffd2, .3, [0, 0, 0], scene);
        this.#scenes[1] = scene;
        this.loadScene(1);
    }

    render() {
        this.#renderer.render(this.#scenes[this.#currentScene], this.#camera);
    }

    loadModel(modelPath, position, name, destScene, onLoad) {
        let model = undefined;
        const r = this;
        function applyProperties(r, model, position, name, sce, onLoad, render) {
            model.position.set(position[0], position[1], position[2]);
            model.name = name == undefined ? "model" : name;
            if (typeof onLoad === 'function') onLoad(model);
            if (sce != undefined) sce.add(model);
            if (render != false) 
                r.render();            
        }
        let scene;
        if (destScene instanceof THREE.Scene) scene = destScene;
        else scene = this.getScene((destScene == undefined || destScene == -1) ? this.#currentScene : destScene);
        switch (lastSplit(modelPath, "\.")) {
            case 'obj': {
                const loader = new loader();
                loader.load(modelPath, function(gltf) {
                    applyProperties(r, model, position, name, scene, onLoad);
                }, undefined, function(error) {
                    console.error('An error occurred loading ' + modelPath, error);
                });
            }
            case "glb": {
                const loader = new GLTFLoader();
                loader.load(modelPath, function(gltf) {
                    model = gltf.scene;
                    applyProperties(r, model, position, name, scene, onLoad, true);
                }, undefined, function(error) {
                    console.error('An error occurred loading ' + modelPath, error);
                });
            }
        }
    }

    getClientWidth() {
        return this.#renderer.domElement.cleanWidth;
    }
    getClientHeight() {
        return this.#renderer.domElement.cleanHeight;
    }

    createLight(type, color, intensity, position, destScene) {
        let scene = undefined;
        if (destScene instanceof THREE.Scene) scene = destScene;
        else scene = r.getScene((destScene == undefined || destScene == -1) ? this.#currentScene : destScene);
        switch (type) {
            case "SPOTLIGHT": {
                const light = new THREE.SpotLight( color, intensity );
                light.position.set(position[0], position[1], position[2]);
                scene.add( light );
                return light;
            }
            case "AMBIENTLIGHT": {
                const light = new THREE.AmbientLight( color, intensity );
                scene.add( light );
                return light;
            }
        }
    }
};

function isNumber(param) {
    return typeof param === 'number' && !isNaN(param);
}


function lastSplit(text, split) {
    let sp = text.split(split);
    return sp[sp.length-1];
}

export { Renderer }

