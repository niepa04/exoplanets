class Rotator {
    constructor(renderer, model, xr, yr, zr) {
        this.model = model;
        renderer.onFrameUpdate((scene, delta) => {
            this.model.rotation.x += xr*delta;
            this.model.rotation.y += yr*delta;
            this.model.rotation.z += zr*delta;
        });
    }
}

export { Rotator }