import * as THREE from 'three';

class TextureSwapper {
    constructor() {}

    swap(object, imageData) {
        if (object instanceof THREE.Object3D) {
            let da = new THREE.DataTexture(imageData.data, imageData.width, imageData.height, THREE.RGBAFormat)
            console.log(object.material.map);
            console.log(da);
            da.needsUpdate = true;
            object.material.map = da;
            object.material.needsUpdate = true;
            object.needsUpdate;
            console.log(object.material.map);
        } else console.error("Object is not of type THREE.Object3D!");
    }

    loadImage(image, onLoad) {
        let img = new Image();
        img.style.display = "none";
        img.src = image;
        let canvas = document.querySelector('#temp_canvas_for_image_manipulation');
        if (canvas == undefined) {
            canvas = document.createElement('canvas');
            canvas.id = "temp_canvas_for_image_manipulation";
            canvas.style.display = "none";
        }
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        img.onload = function() {
            canvas.width = img.width;
            canvas.height = img.height;
            ctx.drawImage(img, 0, 0);
            onLoad(ctx.getImageData(0, 0, canvas.width, canvas.height));
        };   
    }

    changeBrightness(imageData, brightnessFactor) {
        const data = imageData.data;
        for (let i = 0; i < data.length; i += 4) {
            // Modify each color channel (R, G, B)
            data[i]     = data[i] * brightnessFactor;  // Red
            data[i + 1] = data[i + 1] * brightnessFactor;  // Green
            data[i + 2] = data[i + 2] * brightnessFactor;  // Blue
            // Alpha channel remains unchanged (data[i + 3])
        }
        return imageData;
    }
    
    rgbToHsl(rgb) {
        let r = rgb[0] / 255;
        let g = rgb[1] / 255;
        let b = rgb[2] / 255;
        const max = Math.max(r, g, b);
        const min = Math.min(r, g, b);
        let h, s, l = (max + min) / 2;
    
        if (max === min) {
            h = s = 0; // achromatic
        } else {
            const d = max - min;
            s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
            switch (max) {
                case r: h = (g - b) / d + (g < b ? 6 : 0); break;
                case g: h = (b - r) / d + 2; break;
                case b: h = (r - g) / d + 4; break;
            }
            h /= 6;
        }
    
        return [h, s, l];
    }
    
    hslToRgb(hsl) {
        let h = hsl[0];
        let s = hsl[1];
        let l = hsl[2];
        let r, g, b;
        if (s === 0) {
            r = g = b = l; // achromatic
        } else {
            function hue2rgb(p, q, t) {
                if (t < 0) t += 1;
                if (t > 1) t -= 1;
                if (t < 1 / 6) return p + (q - p) * 6 * t;
                if (t < 1 / 3) return q;
                if (t < 1 / 2) return p + (q - p) * (2 / 3 - t) * 6;
                return p;
            }
    
            const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
            const p = 2 * l - q;
            r = hue2rgb(p, q, h + 1 / 3);
            g = hue2rgb(p, q, h);
            b = hue2rgb(p, q, h - 1 / 3);
        }
        return [r * 255, g * 255, b * 255];
    }
}

export { TextureSwapper }