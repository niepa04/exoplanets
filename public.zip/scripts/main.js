import {planety} from "../public/planety.js";//5759 planet
import {Renderer} from './Renderer.js'
import * as THREE from 'three';
import { Orbitor } from './Orbitor.js';
import { Rotator } from './Rotator.js';
function calcXYZ(ab) {
    let a = ab[0];
    let b = ab[1];
    let dl = 10;

    a *= Math.PI / 180;
    b *= Math.PI / 180;
    const an = a < 0;
    if (an) a *= -1;
    const bn = b < 0;
    if (bn) b *= -1;
    let y = Math.sin(b)*dl;
    let c = ctg(b)*y;
    let z = Math.sin(a)*c;
    let x = ctg(a)*z;
    if (an) {
        z *= -1;
        x *= -1;
    }
    if (bn) {
        y *= -1;
        c *= -1;
    }
    function ctg(v) {
        return 1 / Math.tan(v);
    }
    return [x, y, z];
}

document.querySelector('#bcktom').onclick = function() {
  orbs(100000, 1);
  section.style.display = 'none';
    nav.style.width = "30vw"
    r.getCanvas().style.display = 'block';
};

const r = new Renderer(document.getElementById("canva"));
const scene = new THREE.Scene();
let camera = r.getCamera();
camera.position.z = 10;
const model = "./public/planet2.glb";
// r.planetCloseupScene(model, "kjnm");
// document.querySelector("#loading_message").style.display = "none";

function orbs(amnt, dlm) {
    const prev = { x: 0, y: 0 };
    let isDragging = false;
    window.addEventListener("mouseup", function() {
        isDragging = false;
    });
    window.addEventListener('mousedown', function(event) {
        isDragging = true;
        prev.x = event.clientX;
        prev.y = event.clientY;
    });
    window.addEventListener('mousemove', function(event) {
        if (document.hasFocus() && isDragging) {
            camera.rotation.x -= (event.clientY-prev.y)/100;
            camera.rotation.y -= (event.clientX-prev.x)/100;
            prev.x = event.clientX;
            prev.y = event.clientY;
        }
    });
    let indx = 0;
    let hostL = [];
    planety.forEach(pla => {
      if (!hostL.includes(pla.hostname))
        hostL.push(pla.hostname); 
    });
    console.log(hostL);
    r.loadModel("./public/gasGigant.glb", [0, 0, 0], "gass_gigant", scene, (object) => {
      let am = 0;
        for (let pla of planety) {
          if (am >= amnt) break;
          am++;
          // if (hostL.includes(pla.name)) {
            const instance = object.clone();
            let p = calcXYZ([pla.glon, pla.glat]);
            let m = pla.sy_dist*dlm;
            instance.position.set(p[0]*m, p[1]*m, p[2]*m);
            // instance.remove(instance.children[1]);
            // instance.remove(instance.children[2]);
            // instance.remove(instance.children[3]);
            // instance.remove(instance.children[4]);
            // instance.remove(instance.children[5]);
            // instance.remove(instance.children[6]);
            instance.lookAt(camera.position);
            scene.add(instance);
            instance.name = "VERYUNIQUEKEY:"+pla.rowid;
          // }
        }
    });
    camera.position.z = 100;

    camera.rotation.x = 180;

    r.onClickEvent((object) => {
      console.log(object);
        if (object != undefined && object.object != undefined && object.object.parent != undefined) console.log(object.object.parent.name);
    });


    let hasDeviceMotion = false;
    let lastAcceleration = [];
    let i = 0;
    function setLA(a) {
        if (i == 4) i = 0;
        lastAcceleration[i] = a;
        i++;
    }
    let deadZoneA = undefined;
    window.addEventListener('devicemotion', (event) => {
        if (deadZoneA == undefined) deadZoneA = {
            x: event.acceleration.x,
            y: event.acceleration.y,
            z: event.acceleration.z
        }
        window.removeEventListener('devicemotion', this);
    });
    window.addEventListener('devicemotion', function(event) {
        const acceleration = event.acceleration
        const rotationRate = event.rotationRate;
        let delta = r.delta*.01;
        if (rotationRate) {
            hasDeviceMotion = true;
            camera.rotation.z += rotationRate.gamma*.00013;
            camera.rotation.x += rotationRate.alpha*.00013;
            camera.rotation.y += rotationRate.beta*.00013;
        }

        // let ovd = false;
        // if (acceleration) {
        //     camera.position.x -= (acceleration.x-deadZoneA.x)*delta*5000;
        //     camera.position.y -= (acceleration.y-deadZoneA.y)*delta*5000;
        //     camera.position.z -= (acceleration.z-deadZoneA.z)*delta*5000;
        // }
        if (ovd) setLA(acceleration);
    });
    
    scene.background = new THREE.Color(0x000000);   
    r.createLight("AMBIENTLIGHT", 0x909090, 10, [10, 0, 0], scene);
    r.loadScene(scene);
}

orbs(100000, 1);
function menuopen(){
  let aside = document.querySelector('aside');
  let menu = document.querySelector('img');
  aside.style.width = "25%";
  menu.style.right = "25%";
  menu.src = "menu.png";
  menu.onclick = function(){
    menuhide();
  }
}
function menuhide(){
  let aside = document.querySelector('aside');
  let menu = document.querySelector('img');
  aside.style.width = "0%";
  menu.style.right = "0%";
  menu.src = "menu2.png";
  menu.onclick = function(){
    menuopen();
  }
}
function showmore(i){
  let aside = document.querySelector('aside');
  let show = document.querySelector('button');
  aside.innerHTML = "";
  let planeta = planety[i-1];
  for ( let [key, value] of Object.entries(planeta)){
    aside.innerHTML += `${key}: ${value}<br>`;
  };
  aside.innerHTML += "<button>Show less</button>";
  document.querySelector('button').onclick = function(){
    showless(planety[i-1].rowid);
  };
  show.onclick = function (){
    showless(i);
  };
}
function showless(i){
  let aside = document.querySelector('aside');
  let show = document.querySelector('button');
  aside.innerHTML =" Planet name: " + planety[i-1].pl_name + "<br> Star name: " + planety[i-1].hostname + "<br> Planet type: " + planety[i-1].type + "<br> Discovery year: " + planety[i-1].disc_year + "<br> Discovery method: " + planety[i-1].discoverymethod + "<br> Distance from Earth: " + planety[i-1].sy_dist + "pc<br>";
  aside.innerHTML += "<button>Show more</button>";
  document.querySelector('button').onclick = function(){
    showmore(planety[i-1].rowid);
  };
  show.onclick = function (){
    showmore(i);
  };
}
function removeColumnsFromPlanets(planets, columns) {
  planets.forEach(planet => {
      columns.forEach(column => {
          delete planet[column];  // Usunięcie kolumny
      });
  });
  return planets;
}

const nav = document.querySelector("nav");
const form = document.querySelector("form");
const section = document.querySelector("section");
const search = document.querySelector('#plNameInput');
const minYear = document.querySelector('#discoveryYearMin');
const maxYear = document.querySelector('#discoveryYearMax');
const minDistance = document.querySelector('#distanceMin');
const maxDistance = document.querySelector('#distanceMax');
const hostname = document.querySelector('#hostNameInput');
const discoveryMethod = document.querySelector('#discoveryMethod');
const plType = document.querySelector('#plType');

function planet(){
  if(minYear.value>maxYear.value){
    let pom = minYear.value;
    minYear.value = maxYear.value;
    maxYear.value = pom;
  }
  if(minYear.value<1992)
    minYear.value = 1992;
  if(maxYear.value>2024)
    maxYear.value = 2024;
  if(minDistance.value>maxDistance.value){
    let pom = minDistance.value;
    minDistance.value = maxDistance.value;
    maxDistance.value = pom;
  }
  if(minDistance.value<0)
    minDistance.value = 0;
  if(maxDistance.value>10000)
    maxDistance.value = 10000;
  let wynik = [];
  let j = 0;
  planety.forEach(i=>{
    if((i.pl_name).indexOf(search.value) !== -1 && i.hostname.indexOf(hostname.value) !== -1 && i.disc_year>=minYear.value && i.disc_year<=maxYear.value && ((i.sy_dist>=parseFloat(minDistance.value) && i.sy_dist<=parseFloat(maxDistance.value)) || i.sy_dist == '') && (i.discoverymethod == discoveryMethod.value || discoveryMethod.value == '') && (i.type == plType.value || plType.value == '')){
      wynik[j] = i;
      j++;
    }
  })
  if(wynik.length == 1){
    section.style.display = 'none'
    nav.style.width = "30vw";
    r.getCanvas().style.display = 'block';
    r.planetCloseupScene("./public/gasGigant.glb", "planet");
    form.style.display="none";

    document.querySelector('section').innerHTML = "<img src='menu.png' alt='menu'><aside> Planet name: " + wynik[0].pl_name + "<br> Star name: " + wynik[0].hostname + "<br> Planet type: " + wynik[0].type + "<br> Discovery year: " + wynik[0].disc_year + "<br> Discovery method: " + wynik[0].discoverymethod + "<br><div id='predkosciomierz'> Distance from Earth: " + wynik[0].sy_dist + "pc</div><br>" + "<button>Show more</button>" + "</aside>";
    document.querySelector('img').onclick = function(){
      menuhide();
    };
    document.querySelector('button').onclick = function(){
      showmore(wynik[0].rowid);
    };
    let predkosc = document.querySelector('#predkosciomierz');
    predkosc.onclick = function(){
      console.log("test");
    }
  }else if (wynik.length>1){
    section.style.display = 'block';
    nav.style.width = "100vw"
    section.style.width = "100%";
    section.style.height = 'auto';
    nav.style.height = "auto";
    r.getCanvas().style.display = 'none';
    section.innerHTML = "<p>CHOOSE THE PLANET</p>";
    r.planetCloseupScene("./public/gasGigant.glb", "planet");
    // wynik.forEach(i=>{
    //   let element = document.createElement("button");
    //   element.onclick = function(){
        
    //     //RENEEDER
    //     document.querySelector('nav').innerHTML = "<img src='menu.png' alt='menu'><aside> Planet name: " + i.pl_name + "<br> Star name: " + i.hostname + "<br> Planet type: " + i.type + "<br> Discovery year: " + i.disc_year + "<br> Discovery method: " + i.discoverymethod + "<br><div id='predkosciomierz'> Distance from Earth: " + i.sy_dist + "pc</div><br>" + "<button>Show more</button>" + "</aside>";
    //     document.querySelector('img').onclick = function(){
    //       menuhide();
    //     };
    //     document.querySelector('button').onclick = function(){
    //       showmore(i.rowid);
    //     };
    //     let predkosc = document.querySelector('#predkosciomierz');
    //     predkosc.onclick = function(){
    //       console.log("test");
    //     }
    //   };
    //   element.innerHTML = "Planet name: " + i.pl_name + "<br> Star name: " + i.hostname + "<br> Planet type: " + i.type + "<br> Discovery year: " + i.disc_year + "<br> Discovery method: " + i.discoverymethod + "<br> Distance from Earth: " + i.sy_dist + "pc";
    //   document.querySelector('nav').appendChild(element);
    //   section.style.display = 'none'
    //   nav.style.width = "30vw";
    //   r.getCanvas().style.display = 'block';
    // });
    wynik.forEach(i=>{
      let element = document.createElement("button");
      element.onclick = function(){
        
        //RENEEDER
        section.innerHTML = "<img src='menu.png' alt='menu'><aside> Planet name: " + i.pl_name + "<br> Star name: " + i.hostname + "<br> Planet type: " + i.type + "<br> Discovery year: " + i.disc_year + "<br> Discovery method: " + i.discoverymethod + "<br><div id='predkosciomierz'> Distance from Earth: " + i.sy_dist + "pc</div><br>" + "<button>Show more</button>" + "</aside>";
        section.querySelector('img').onclick = function(){
          menuhide();
        };
        section.querySelector('button').onclick = function(){
          showmore(i.rowid);
        };
        let predkosc = section.querySelector('#predkosciomierz');
        predkosc.onclick = function(){
          console.log("test");
        }
        section.style.display = 'none'
    nav.style.width = "30vw";
    r.getCanvas().style.display = 'block';
    r.planetCloseupScene("./public/gasGigant.glb", "planet");
    form.style.display="none";
      };
      element.innerHTML = "Planet name: " + i.pl_name + "<br> Star name: " + i.hostname + "<br> Planet type: " + i.type + "<br> Discovery year: " + i.disc_year + "<br> Discovery method: " + i.discoverymethod + "<br> Distance from Earth: " + i.sy_dist + "pc";
      section.appendChild(element);
    });
  }else
    alert("No planet found");
  console.log("Planets found: " + j);
}
document.querySelector('#submit').addEventListener("click", planet);
r.start();
document.querySelector("#loading_message").style.display = "none";
document.querySelector('form').style.display = 'block';