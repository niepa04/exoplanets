import {Renderer} from './Renderer.js'
import * as THREE from 'three';
import { planety } from "../public/planety.js";
import { Orbitor } from './Orbitor.js';
import { Rotator } from './Rotator.js';
function calcXYZ(ab) {
    let a = ab[0];
    let b = ab[1];
    let dl = 10;

    a *= Math.PI / 180;
    b *= Math.PI / 180;
    const an = a < 0;
    if (an) a *= -1;
    const bn = b < 0;
    if (bn) b *= -1;
    let y = Math.sin(b)*dl;
    let c = ctg(b)*y;
    let z = Math.sin(a)*c;
    let x = ctg(a)*z;
    if (an) {
        z *= -1;
        x *= -1;
    }
    if (bn) {
        y *= -1;
        c *= -1;
    }
    function ctg(v) {
        return 1 / Math.tan(v);
    }
    return [x, y, z];
}

const r = new Renderer(document.getElementById("canva"));
r.getCanvas().style.display = "block";
const scene = new THREE.Scene();
let camera = r.getCamera();
camera.position.z = 10;
const model = "./public/planet2.glb";
// r.planetCloseupScene(model, "kjnm");
// document.querySelector("#loading_message").style.display = "none";


function orbs() {
    const prev = { x: 0, y: 0 };
    let isDragging = false;
    window.addEventListener("mouseup", function() {
        isDragging = false;
    });
    window.addEventListener('mousedown', function(event) {
        isDragging = true;
        prev.x = event.clientX;
        prev.y = event.clientY;
    });
    window.addEventListener('mousemove', function(event) {
        if (document.hasFocus() && isDragging) {
            camera.rotation.x -= (event.clientY-prev.y)/100;
            camera.rotation.y -= (event.clientX-prev.x)/100;
            prev.x = event.clientX;
            prev.y = event.clientY;
        }
    });
    let indx = 0;
    r.loadModel("./public/gasGigant.glb", [0, 0, 0], "gass_gigant", scene, (object) => {
        for (let pla of planety) {
            const instance = object.clone();
            let p = calcXYZ([pla.glon, pla.glat]);
            let m = pla.sy_dist;
            instance.position.set(p[0]*m, p[1]*m, p[2]*m);
            // instance.remove(instance.children[1]);
            // instance.remove(instance.children[2]);
            // instance.remove(instance.children[3]);
            // instance.remove(instance.children[4]);
            // instance.remove(instance.children[5]);
            // instance.remove(instance.children[6]);
            instance.lookAt(camera.position);
            scene.add(instance);
            instance.name = "VERYUNIQUEKEY:"+pla.rowid;
        }
    });
    camera.position.z = 100;

    camera.rotation.x = 180;

    r.onClickEvent((object) => {
        if (object != undefined && object.object != undefined && object.object.parent != undefined) console.log(object.object.parent.name);
    });


    let hasDeviceMotion = false;
    let lastAcceleration = [];
    let i = 0;
    function setLA(a) {
        if (i == 4) i = 0;
        lastAcceleration[i] = a;
        i++;
    }
    let deadZoneA = undefined;
    window.addEventListener('devicemotion', (event) => {
        if (deadZoneA == undefined) deadZoneA = {
            x: event.acceleration.x,
            y: event.acceleration.y,
            z: event.acceleration.z
        }
        window.removeEventListener('devicemotion', this);
    });
    window.addEventListener('devicemotion', function(event) {
        const acceleration = event.acceleration
        const rotationRate = event.rotationRate;
        let delta = r.delta*.01;
        if (rotationRate) {
            hasDeviceMotion = true;
            camera.rotation.z += rotationRate.gamma*.00013;
            camera.rotation.x += rotationRate.alpha*.00013;
            camera.rotation.y += rotationRate.beta*.00013;
        }

        // let ovd = false;
        // if (acceleration) {
        //     camera.position.x -= (acceleration.x-deadZoneA.x)*delta*5000;
        //     camera.position.y -= (acceleration.y-deadZoneA.y)*delta*5000;
        //     camera.position.z -= (acceleration.z-deadZoneA.z)*delta*5000;
        // }
        if (ovd) setLA(acceleration);
    });
    
    scene.background = new THREE.Color(0x000000);   
    r.createLight("AMBIENTLIGHT", 0x909090, 10, [10, 0, 0], scene);
    r.loadScene(scene);
}

orbs();
r.start();

function sem() {
    camera.position.z = 10;
    camera.position.x = 5;
    camera.position.y = 4;
    r.planetCloseupScene(model, "sun");
    document.querySelector("#loading_message").style.display = "none";
    r.start();
    r.runInBKG(true);
    for (let i = 0; i < 20; i++) {
        r.loadModel(model, [i*3, 0, 0], "sun", scene, (sun) => {
            // new MouseRotator(nigger, sun, new MouseRotatorOptions(10, 5, 2, -0.5));
            r.scale(sun, 2.5);
            r.loadModel(model, [0, 0, 0], "earth", scene, (earth) => {
                // ts.loadImage("./public/polish.jpg", (data) => {
                //     ts.swap(earth, data);
                // });
                earth.rotation.z = .3;
                new Orbitor(r, sun, earth, 10, .2).init();
                r.loadModel(model, [0, 0, 0], "moon", scene, (moon) => {
                    new Orbitor(r, earth, moon, 4, -2).init();
                    r.scale(moon, .5);
                    new Rotator(r, moon.children[0], 0, -.2, 0);
                });
            });
        });
        scene.background = new THREE.Color(0x070707);   
        r.createLight("SPOTLIGHT", 0x909090, 10, [2, 0, 0], scene);
        r.createLight("SPOTLIGHT", 0x909090, 10, [-2, 0, 0], scene);
        r.createLight("AMBIENTLIGHT", 0xffffd2, .3, [0, 0, 0], scene);
        r.loadScene(scene);
    }
}

document.querySelector("#loading_message").style.display = "none";


    // // const scene = new THREE.Scene();
    // // let mr = new MouseRotator(r, [], new MouseRotatorOptions(10, 5, 0, 0));
    // // r.loadModel("./public/cosmos.glb", "GLB", [0, 0, 0], "planet", scene);
    // // r.getCamera().position.z = 1;
    // // scene.background = new THREE.Color(0x070707);   
    // // r.createLight("AMBIENTLIGHT", 0xffffff, 1, [0, 10, 0], scene);
    // // r.loadScene(scene);
    // // r.listenOnCanvas("wheel", (event) => {
    // //     r.getCamera().position.z += event.deltaY*.002;
    // // });

    // // r.getScene().background = 0x070707;
    // // r.createLight("SPOTLIGHT", 0xffffff, 100, [10, 0, 0], r.getScene());
 